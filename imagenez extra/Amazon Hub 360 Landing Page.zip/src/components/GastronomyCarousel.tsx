import { MapPin, ChevronLeft, ChevronRight } from 'lucide-react';
import { useRef } from 'react';

interface Restaurant {
  id: string;
  name: string;
  dish: string;
  image: string;
  cuisine: string;
  location: string;
}

const GastronomyCarousel = () => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const restaurants: Restaurant[] = [
    {
      id: '1',
      name: 'Al Frío y al Fuego',
      dish: 'Paiche a la Plancha',
      image: 'https://images.unsplash.com/photo-1700769709690-ff47122b48c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXJ1dmlhbiUyMGZvb2QlMjBkaXNofGVufDF8fHx8MTc2NzgwNzY1NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      cuisine: 'Amazonian Fusion',
      location: 'Malecón Tarapacá',
    },
    {
      id: '2',
      name: 'Dawn on the Amazon Café',
      dish: 'Tacacho con Cecina',
      image: 'https://images.unsplash.com/photo-1706129238925-e49f65fb272f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cm9waWNhbCUyMHJlc3RhdXJhbnR8ZW58MXx8fHwxNzY3ODA3NjU0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      cuisine: 'Traditional Peruvian',
      location: 'Plaza de Armas',
    },
    {
      id: '3',
      name: 'Jungle Gastronomy',
      dish: 'Juane Special',
      image: 'https://images.unsplash.com/photo-1565242660110-8983d0104b8c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyaXZlciUyMGJvYXQlMjB0cmFuc3BvcnRhdGlvbnxlbnwxfHx8fDE3Njc4MDc2NTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      cuisine: 'River Cuisine',
      location: 'Belén Market',
    },
    {
      id: '4',
      name: 'Mitos y Cubiertos',
      dish: 'Patarashca',
      image: 'https://images.unsplash.com/photo-1760959192322-bd8981915ba6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aWxkbGlmZSUyMHBob3RvZ3JhcGh5JTIwbWFjcm98ZW58MXx8fHwxNzY3ODA3NjUzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      cuisine: 'Indigenous',
      location: 'San Juan',
    },
  ];

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 400;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section className="py-24 px-8 bg-[#0A3323] text-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)',
          backgroundSize: '50px 50px',
        }} />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="flex items-end justify-between mb-12">
          <div>
            <h2 className="text-5xl font-playfair mb-4">
              Gastronomy & Reservations
            </h2>
            <p className="text-xl text-white/80">
              Reserve your table at Iquitos' finest restaurants
            </p>
          </div>

          {/* Navigation Buttons */}
          <div className="flex gap-3">
            <button
              onClick={() => scroll('left')}
              className="w-12 h-12 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-all backdrop-blur-sm border border-white/20"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              onClick={() => scroll('right')}
              className="w-12 h-12 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-all backdrop-blur-sm border border-white/20"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Scrollable Carousel */}
        <div
          ref={scrollRef}
          className="flex gap-6 overflow-x-auto pb-4"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {restaurants.map((restaurant) => (
            <div
              key={restaurant.id}
              className="flex-shrink-0 w-96 bg-white/10 backdrop-blur-md rounded-3xl overflow-hidden border border-white/20 hover:border-[#FF6B35] transition-all group"
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={restaurant.image}
                  alt={restaurant.dish}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                
                {/* Cuisine Badge */}
                <div className="absolute top-4 right-4">
                  <div className="bg-[#FF6B35] text-white px-4 py-2 rounded-full text-sm shadow-lg">
                    {restaurant.cuisine}
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-2xl text-white mb-2 group-hover:text-[#FF6B35] transition-colors">
                  {restaurant.name}
                </h3>
                <p className="text-[#E8DCCA] mb-4 text-lg">
                  Signature: {restaurant.dish}
                </p>

                <div className="flex items-center gap-2 mb-6 text-white/70">
                  <MapPin className="w-4 h-4" />
                  <span className="text-sm">{restaurant.location}</span>
                </div>

                {/* CTA Button */}
                <button className="w-full px-6 py-3 bg-[#FF6B35] text-white rounded-xl hover:bg-[#FF6B35]/90 transition-all shadow-lg hover:shadow-xl">
                  Reserve Table
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default GastronomyCarousel;