import { Sparkles, Send } from 'lucide-react';
import { useState } from 'react';

const AIAssistant = () => {
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const chips = [
    { label: 'Adventure', icon: '🏔️' },
    { label: 'Relax', icon: '🌴' },
    { label: 'Gastronomy', icon: '🍽️' },
    { label: 'Eco-Tours', icon: '🌿' },
  ];

  const handleSubmit = () => {
    if (input.trim()) {
      setIsTyping(true);
      setTimeout(() => setIsTyping(false), 3000);
    }
  };

  return (
    <div className="relative z-20 max-w-7xl mx-auto px-8 -mt-32">
      <div className="glassmorphism rounded-3xl p-8 shadow-2xl border-2 border-white/30">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-gradient-to-br from-[#FF6B35] to-[#0A3323] rounded-2xl flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-2xl text-[#0A3323] font-playfair">Amazon AI Planner</h3>
            <p className="text-sm text-[#0A3323]/70">Let AI craft your perfect journey</p>
          </div>
        </div>

        {/* Chips */}
        <div className="flex flex-wrap gap-3 mb-6">
          {chips.map((chip) => (
            <button
              key={chip.label}
              className="px-4 py-2 bg-white/80 hover:bg-[#E8DCCA] text-[#0A3323] rounded-full border border-[#0A3323]/20 transition-all flex items-center gap-2 shadow-sm hover:shadow-md"
            >
              <span>{chip.icon}</span>
              <span className="text-sm">{chip.label}</span>
            </button>
          ))}
        </div>

        {/* Input Area */}
        <div className="relative">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Tell me your budget and dates, and I'll plan your perfect Amazon experience..."
            className="w-full px-6 py-4 pr-16 rounded-2xl bg-white/90 text-[#0A3323] placeholder:text-[#0A3323]/50 border-2 border-transparent focus:border-[#FF6B35] focus:outline-none shadow-md resize-none h-28"
          />
          <button
            onClick={handleSubmit}
            className="absolute right-4 bottom-4 w-10 h-10 bg-[#FF6B35] text-white rounded-xl hover:bg-[#FF6B35]/90 transition-all shadow-md flex items-center justify-center"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>

        {/* Typing Indicator */}
        {isTyping && (
          <div className="mt-4 flex items-center gap-2 text-[#0A3323]/70">
            <div className="flex gap-1">
              <span className="w-2 h-2 bg-[#FF6B35] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-2 h-2 bg-[#FF6B35] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-2 h-2 bg-[#FF6B35] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
            <span className="text-sm">AI is crafting your itinerary...</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIAssistant;
