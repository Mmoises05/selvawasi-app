import { Star, Clock, Eye, MapPin } from 'lucide-react';

interface Experience {
  id: string;
  title: string;
  image: string;
  price: string;
  duration: string;
  rating: number;
  reviews: number;
  has360: boolean;
  location: string;
}

const ExperiencesMarketplace = () => {
  const experiences: Experience[] = [
    {
      id: '1',
      title: 'Canopy Zipline & Wildlife Trek',
      image: 'https://images.unsplash.com/photo-1738625256303-d07f7c459982?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqdW5nbGUlMjBjYW5vcHklMjBkcm9uZXxlbnwxfHx8fDE3Njc4MDc2NTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      price: '$180',
      duration: '3D / 2N',
      rating: 4.9,
      reviews: 234,
      has360: true,
      location: 'Pacaya-Samiria Reserve',
    },
    {
      id: '2',
      title: 'Pink Dolphin Encounter',
      image: 'https://images.unsplash.com/photo-1703778604688-0d7037716fd7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbWF6b24lMjBqdW5nbGUlMjBhZHZlbnR1cmV8ZW58MXx8fHwxNzY3ODA3NjUzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      price: '$95',
      duration: '1D',
      rating: 4.8,
      reviews: 187,
      has360: true,
      location: 'Nauta Caño',
    },
    {
      id: '3',
      title: 'Luxury Jungle Lodge Retreat',
      image: 'https://images.unsplash.com/photo-1704502889897-83d6ebcca97e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyYWluZm9yZXN0JTIwbG9kZ2V8ZW58MXx8fHwxNzY3ODA3NjU0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      price: '$320',
      duration: '4D / 3N',
      rating: 5.0,
      reviews: 156,
      has360: true,
      location: 'Yarapa River',
    },
  ];

  return (
    <section className="py-24 px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-5xl text-[#0A3323] font-playfair mb-4">
            Premium Experiences Marketplace
          </h2>
          <p className="text-xl text-[#0A3323]/70">
            Curated adventures verified by local guides
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {experiences.map((experience) => (
            <div
              key={experience.id}
              className="group bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 border border-[#0A3323]/10"
            >
              {/* Image Container */}
              <div className="relative h-72 overflow-hidden">
                <img
                  src={experience.image}
                  alt={experience.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                
                {/* Badges */}
                <div className="absolute top-4 left-4 flex flex-col gap-2">
                  <div className="bg-[#FF6B35] text-white px-4 py-2 rounded-full text-sm shadow-lg">
                    {experience.price}
                  </div>
                  <div className="bg-white/95 text-[#0A3323] px-4 py-2 rounded-full text-sm shadow-lg flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {experience.duration}
                  </div>
                </div>

                {experience.has360 && (
                  <div className="absolute top-4 right-4">
                    <div className="bg-white/95 text-[#0A3323] px-3 py-2 rounded-full text-xs shadow-lg flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      360° View
                    </div>
                  </div>
                )}

                {/* Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl text-[#0A3323] mb-3 group-hover:text-[#FF6B35] transition-colors">
                  {experience.title}
                </h3>

                <div className="flex items-center gap-2 mb-4 text-sm text-[#0A3323]/70">
                  <MapPin className="w-4 h-4" />
                  <span>{experience.location}</span>
                </div>

                {/* Rating */}
                <div className="flex items-center justify-between pt-4 border-t border-[#0A3323]/10">
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(experience.rating)
                              ? 'fill-[#FF6B35] text-[#FF6B35]'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-[#0A3323]">{experience.rating}</span>
                  </div>
                  <span className="text-xs text-[#0A3323]/60">
                    ({experience.reviews} reviews)
                  </span>
                </div>

                {/* CTA Button */}
                <button className="w-full mt-4 px-6 py-3 bg-[#0A3323] text-white rounded-xl hover:bg-[#FF6B35] transition-all shadow-md hover:shadow-lg">
                  Book Experience
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ExperiencesMarketplace;
