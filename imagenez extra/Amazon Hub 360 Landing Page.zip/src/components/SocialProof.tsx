import { Star, CheckCircle, MessageCircle } from 'lucide-react';

interface Testimonial {
  id: string;
  name: string;
  avatar: string;
  verified: boolean;
  rating: number;
  quote: string;
  date: string;
  location: string;
}

interface ForumThread {
  id: string;
  title: string;
  author: string;
  replies: number;
  views: number;
}

const SocialProof = () => {
  const testimonials: Testimonial[] = [
    {
      id: '1',
      name: 'Sarah Martinez',
      avatar: 'https://i.pravatar.cc/150?img=1',
      verified: true,
      rating: 5,
      quote: 'The AI planner helped us discover hidden gems in Iquitos we would have never found on our own. The river logistics tracker was a lifesaver!',
      date: 'Jan 2026',
      location: 'Barcelona, Spain',
    },
    {
      id: '2',
      name: 'James Chen',
      avatar: 'https://i.pravatar.cc/150?img=12',
      verified: true,
      rating: 5,
      quote: 'Best platform for Amazon adventures. Real-time boat tracking and seamless restaurant reservations made our trip stress-free.',
      date: 'Dec 2025',
      location: 'Singapore',
    },
    {
      id: '3',
      name: 'Maria Silva',
      avatar: 'https://i.pravatar.cc/150?img=5',
      verified: true,
      rating: 5,
      quote: 'The 360° experience previews are incredible! We booked the canopy zipline tour and it exceeded all expectations.',
      date: 'Jan 2026',
      location: 'São Paulo, Brazil',
    },
  ];

  const forumThreads: ForumThread[] = [
    {
      id: '1',
      title: 'First time in Iquitos - What should I not miss?',
      author: 'TravelBug23',
      replies: 47,
      views: 1203,
    },
    {
      id: '2',
      title: 'Best time for pink dolphin encounters?',
      author: 'NatureLover88',
      replies: 23,
      views: 856,
    },
    {
      id: '3',
      title: 'Local food recommendations near Belén Market',
      author: 'FoodieExplorer',
      replies: 31,
      views: 672,
    },
  ];

  return (
    <section className="py-24 px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-5xl text-[#0A3323] font-playfair mb-4">
            Traveler Forum & Stories
          </h2>
          <p className="text-xl text-[#0A3323]/70">
            Real experiences from our community of Amazon explorers
          </p>
        </div>

        {/* Testimonials */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="bg-gradient-to-br from-[#E8DCCA]/30 to-white rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all border border-[#0A3323]/10"
            >
              {/* Header */}
              <div className="flex items-start gap-4 mb-6">
                <img
                  src={testimonial.avatar}
                  alt={testimonial.name}
                  className="w-16 h-16 rounded-full object-cover border-4 border-white shadow-lg"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="text-lg text-[#0A3323]">
                      {testimonial.name}
                    </h4>
                    {testimonial.verified && (
                      <CheckCircle className="w-5 h-5 text-blue-500" />
                    )}
                  </div>
                  <p className="text-sm text-[#0A3323]/60">{testimonial.location}</p>
                </div>
              </div>

              {/* Rating */}
              <div className="flex items-center gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-5 h-5 ${
                      i < testimonial.rating
                        ? 'fill-[#FF6B35] text-[#FF6B35]'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>

              {/* Quote */}
              <p className="text-[#0A3323]/80 leading-relaxed mb-4 italic">
                "{testimonial.quote}"
              </p>

              {/* Date */}
              <p className="text-sm text-[#0A3323]/50">{testimonial.date}</p>
            </div>
          ))}
        </div>

        {/* Forum Preview */}
        <div className="bg-[#0A3323] rounded-3xl p-8 text-white">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-3xl font-playfair mb-2">Community Forum</h3>
              <p className="text-white/80">Join the conversation with fellow travelers</p>
            </div>
            <button className="px-6 py-3 bg-[#FF6B35] text-white rounded-xl hover:bg-[#FF6B35]/90 transition-all shadow-lg">
              View All Threads
            </button>
          </div>

          <div className="space-y-4">
            {forumThreads.map((thread) => (
              <div
                key={thread.id}
                className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/15 transition-all border border-white/10 cursor-pointer"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <h4 className="text-lg text-white mb-2 hover:text-[#FF6B35] transition-colors">
                      {thread.title}
                    </h4>
                    <p className="text-sm text-white/60">
                      Started by {thread.author}
                    </p>
                  </div>
                  <div className="flex gap-6 text-white/70">
                    <div className="flex items-center gap-2">
                      <MessageCircle className="w-4 h-4" />
                      <span className="text-sm">{thread.replies}</span>
                    </div>
                    <div className="text-sm">
                      {thread.views.toLocaleString()} views
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SocialProof;
