import { Search, Ship, Utensils, Compass } from 'lucide-react';
import { useState } from 'react';

const HeroSection = () => {
  const [activeTab, setActiveTab] = useState<'boats' | 'experiences' | 'restaurants'>('boats');

  return (
    <section className="relative w-full h-screen min-h-[900px] flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1534861542011-27e852f7c9f5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbWF6b24lMjByaXZlciUyMGFlcmlhbHxlbnwxfHx8fDE3Njc4MDc2NTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Amazon River Aerial View"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0A3323]/60 via-[#0A3323]/40 to-[#0A3323]/70" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-8 py-24 w-full text-center">
        <div className="mb-12">
          <h1 className="font-playfair text-6xl md:text-7xl lg:text-8xl text-white mb-6 leading-tight">
            Discover the Magic<br />of Iquitos
          </h1>
          <p className="text-xl md:text-2xl text-[#E8DCCA] max-w-3xl mx-auto leading-relaxed">
            Navigate the Amazon with real-time logistics, curated experiences, and local wisdom
          </p>
        </div>

        {/* Unified Search Bar */}
        <div className="max-w-4xl mx-auto">
          <div className="glassmorphism rounded-3xl p-8 shadow-2xl">
            {/* Tabs */}
            <div className="flex gap-4 mb-6 border-b border-white/20 pb-4">
              <button
                onClick={() => setActiveTab('boats')}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl transition-all ${
                  activeTab === 'boats'
                    ? 'bg-[#FF6B35] text-white shadow-lg'
                    : 'bg-white/50 text-[#0A3323] hover:bg-white/70'
                }`}
              >
                <Ship className="w-5 h-5" />
                <span>Boats</span>
              </button>
              <button
                onClick={() => setActiveTab('experiences')}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl transition-all ${
                  activeTab === 'experiences'
                    ? 'bg-[#FF6B35] text-white shadow-lg'
                    : 'bg-white/50 text-[#0A3323] hover:bg-white/70'
                }`}
              >
                <Compass className="w-5 h-5" />
                <span>Experiences</span>
              </button>
              <button
                onClick={() => setActiveTab('restaurants')}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl transition-all ${
                  activeTab === 'restaurants'
                    ? 'bg-[#FF6B35] text-white shadow-lg'
                    : 'bg-white/50 text-[#0A3323] hover:bg-white/70'
                }`}
              >
                <Utensils className="w-5 h-5" />
                <span>Restaurants</span>
              </button>
            </div>

            {/* Search Input */}
            <div className="flex gap-4">
              <div className="flex-1 relative">
                <input
                  type="text"
                  placeholder={
                    activeTab === 'boats'
                      ? 'Where do you want to go? (e.g., Santa Rosa, Leticia)'
                      : activeTab === 'experiences'
                      ? 'What adventure are you seeking?'
                      : 'Find restaurants, dishes, or cuisines...'
                  }
                  className="w-full px-6 py-4 rounded-xl bg-white/90 text-[#0A3323] placeholder:text-[#0A3323]/50 border-2 border-transparent focus:border-[#FF6B35] focus:outline-none shadow-md"
                />
              </div>
              <button className="px-8 py-4 bg-[#FF6B35] text-white rounded-xl hover:bg-[#FF6B35]/90 transition-all shadow-lg hover:shadow-xl flex items-center gap-2">
                <Search className="w-5 h-5" />
                <span>Search</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
