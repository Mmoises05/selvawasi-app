interface TimelineEvent {
  id: string;
  year: string;
  title: string;
  description: string;
  oldImage: string;
  newImage: string;
}

const CulturalTimeline = () => {
  const events: TimelineEvent[] = [
    {
      id: '1',
      year: '1757',
      title: 'Foundation of Iquitos',
      description: 'Founded as a Jesuit mission on the banks of the Amazon River, Iquitos became a strategic point for exploration.',
      oldImage: 'https://images.unsplash.com/photo-1534861542011-27e852f7c9f5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbWF6b24lMjByaXZlciUyMGFlcmlhbHxlbnwxfHx8fDE3Njc4MDc2NTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      newImage: 'https://images.unsplash.com/photo-1565242660110-8983d0104b8c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyaXZlciUyMGJvYXQlMjB0cmFuc3BvcnRhdGlvbnxlbnwxfHx8fDE3Njc4MDc2NTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      id: '2',
      year: '1880-1914',
      title: 'Rubber Boom Era',
      description: 'The rubber boom transformed Iquitos into one of South America\'s wealthiest cities, building iconic structures like Casa de Fierro.',
      oldImage: 'https://images.unsplash.com/photo-1738625256303-d07f7c459982?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqdW5nbGUlMjBjYW5vcHklMjBkcm9uZXxlbnwxfHx8fDE3Njc4MDc2NTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      newImage: 'https://images.unsplash.com/photo-1703778604688-0d7037716fd7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbWF6b24lMjBqdW5nbGUlMjBhZHZlbnR1cmV8ZW58MXx8fHwxNzY3ODA3NjUzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      id: '3',
      year: '1960s',
      title: 'Oil Discovery',
      description: 'The discovery of oil in the Amazon region brought new economic opportunities and infrastructure development to Iquitos.',
      oldImage: 'https://images.unsplash.com/photo-1760959192322-bd8981915ba6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aWxkbGlmZSUyMHBob3RvZ3JhcGh5JTIwbWFjcm98ZW58MXx8fHwxNzY3ODA3NjUzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      newImage: 'https://images.unsplash.com/photo-1700769709690-ff47122b48c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXJ1dmlhbiUyMGZvb2QlMjBkaXNofGVufDF8fHx8MTc2NzgwNzY1NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      id: '4',
      year: 'Present',
      title: 'Eco-Tourism Hub',
      description: 'Today, Iquitos serves as the gateway to the Amazon, welcoming thousands of eco-tourists seeking authentic jungle experiences.',
      oldImage: 'https://images.unsplash.com/photo-1706129238925-e49f65fb272f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cm9waWNhbCUyMHJlc3RhdXJhbnR8ZW58MXx8fHwxNzY3ODA3NjU0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      newImage: 'https://images.unsplash.com/photo-1704502889897-83d6ebcca97e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyYWluZm9yZXN0JTIwbG9kZ2V8ZW58MXx8fHwxNzY3ODA3NjU0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
  ];

  return (
    <section className="py-24 px-8 bg-[#E8DCCA]/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-5xl text-[#0A3323] font-playfair mb-4">
            History of Iquitos
          </h2>
          <p className="text-xl text-[#0A3323]/70">
            A journey through time in the heart of the Amazon
          </p>
        </div>

        <div className="relative">
          {/* Vertical Timeline Line */}
          <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-[#0A3323] via-[#FF6B35] to-[#0A3323]" />

          {/* Timeline Events */}
          <div className="space-y-24">
            {events.map((event, index) => (
              <div key={event.id} className="relative">
                {/* Timeline Dot */}
                <div className="absolute left-1/2 transform -translate-x-1/2 w-6 h-6 bg-[#FF6B35] rounded-full border-4 border-white shadow-lg z-10" />

                {/* Content - Alternating Sides */}
                <div className={`grid grid-cols-2 gap-16 items-center ${
                  index % 2 === 0 ? '' : 'direction-rtl'
                }`}>
                  {/* Left Side - Old Image */}
                  <div className={index % 2 === 0 ? 'text-right' : 'text-left'}>
                    <div className="inline-block">
                      <div className="relative group">
                        <img
                          src={event.oldImage}
                          alt={`${event.title} - Historical`}
                          className="w-full h-64 object-cover rounded-2xl shadow-xl border-4 border-white"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent rounded-2xl" />
                        <div className="absolute bottom-4 left-4 right-4">
                          <span className="text-white/90 text-sm bg-black/50 px-3 py-1 rounded-full backdrop-blur-sm">
                            Historical
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right Side - New Image */}
                  <div className={index % 2 === 0 ? 'text-left' : 'text-right'}>
                    <div className="inline-block">
                      <div className="relative group">
                        <img
                          src={event.newImage}
                          alt={`${event.title} - Modern`}
                          className="w-full h-64 object-cover rounded-2xl shadow-xl border-4 border-white"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent rounded-2xl" />
                        <div className="absolute bottom-4 left-4 right-4">
                          <span className="text-white/90 text-sm bg-black/50 px-3 py-1 rounded-full backdrop-blur-sm">
                            Modern Day
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Caption - Centered */}
                <div className="mt-8">
                  <div className="max-w-2xl mx-auto bg-white rounded-3xl p-8 shadow-lg border border-[#0A3323]/10">
                    <div className="text-center">
                      <div className="inline-block px-6 py-2 bg-[#FF6B35] text-white rounded-full mb-4">
                        {event.year}
                      </div>
                      <h3 className="text-2xl text-[#0A3323] font-playfair mb-4">
                        {event.title}
                      </h3>
                      <p className="text-[#0A3323]/80 leading-relaxed">
                        {event.description}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CulturalTimeline;
