import { MapPin, Clock, DollarSign, Ship, CheckCircle2, AlertCircle } from 'lucide-react';

interface DepartureCard {
  id: string;
  boatName: string;
  route: { from: string; to: string };
  status: 'On Time' | 'Delayed' | 'Boarding';
  departure: string;
  price: string;
}

const RiverLogistics = () => {
  const departures: DepartureCard[] = [
    {
      id: '1',
      boatName: 'Rio Amazonas Express',
      route: { from: 'Iquitos', to: 'Santa Rosa' },
      status: 'On Time',
      departure: '14:30',
      price: '$45',
    },
    {
      id: '2',
      boatName: 'Dolphin Cruiser',
      route: { from: 'Iquitos', to: 'Leticia' },
      status: 'Boarding',
      departure: '15:00',
      price: '$65',
    },
    {
      id: '3',
      boatName: 'Amazon Navigator',
      route: { from: 'Iquitos', to: 'Tabatinga' },
      status: 'On Time',
      departure: '16:45',
      price: '$52',
    },
    {
      id: '4',
      boatName: 'Jungle Ferry III',
      route: { from: 'Iquitos', to: 'Pebas' },
      status: 'Delayed',
      departure: '17:20',
      price: '$38',
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'On Time':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'Boarding':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Delayed':
        return 'bg-red-100 text-red-700 border-red-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'On Time':
        return <CheckCircle2 className="w-4 h-4" />;
      case 'Delayed':
        return <AlertCircle className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  return (
    <section className="py-24 px-8 bg-[#E8DCCA]/20">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-5xl text-[#0A3323] font-playfair mb-4">
            Real-Time River Connectivity
          </h2>
          <p className="text-xl text-[#0A3323]/70">
            Track boats, ferries, and water taxis across the Amazon basin
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Left Column: Mini Map */}
          <div className="bg-white rounded-3xl p-8 shadow-xl">
            <h3 className="text-2xl text-[#0A3323] mb-6">Active Routes</h3>
            
            {/* Simplified River Map Illustration */}
            <div className="relative h-96 bg-gradient-to-br from-[#0A3323]/10 to-[#0A3323]/5 rounded-2xl p-8">
              {/* River Path */}
              <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 400">
                <path
                  d="M 50 200 Q 150 150, 200 200 T 350 180"
                  stroke="#0A3323"
                  strokeWidth="8"
                  fill="none"
                  strokeLinecap="round"
                  opacity="0.3"
                />
                <path
                  d="M 50 200 Q 150 250, 200 200 T 350 220"
                  stroke="#0A3323"
                  strokeWidth="8"
                  fill="none"
                  strokeLinecap="round"
                  opacity="0.2"
                />
              </svg>

              {/* Location Markers */}
              <div className="absolute top-1/2 left-8 transform -translate-y-1/2">
                <div className="w-4 h-4 bg-[#FF6B35] rounded-full border-4 border-white shadow-lg" />
                <span className="absolute top-6 left-1/2 transform -translate-x-1/2 text-xs text-[#0A3323] whitespace-nowrap">
                  Iquitos
                </span>
              </div>

              <div className="absolute top-1/4 right-1/3 transform -translate-y-1/2">
                <div className="w-3 h-3 bg-[#0A3323] rounded-full border-4 border-white shadow-lg" />
                <span className="absolute top-6 left-1/2 transform -translate-x-1/2 text-xs text-[#0A3323] whitespace-nowrap">
                  Santa Rosa
                </span>
              </div>

              <div className="absolute top-1/3 right-12">
                <div className="w-3 h-3 bg-[#0A3323] rounded-full border-4 border-white shadow-lg" />
                <span className="absolute top-6 left-1/2 transform -translate-x-1/2 text-xs text-[#0A3323] whitespace-nowrap">
                  Leticia
                </span>
              </div>

              {/* Animated Boat */}
              <div className="absolute top-1/2 left-1/4 transform -translate-y-1/2 animate-pulse">
                <Ship className="w-6 h-6 text-[#FF6B35]" />
              </div>
            </div>
          </div>

          {/* Right Column: Next Departures */}
          <div className="space-y-4">
            <h3 className="text-2xl text-[#0A3323] mb-6">Next Departures</h3>
            
            {departures.map((departure) => (
              <div
                key={departure.id}
                className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-[#0A3323]/10"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-[#0A3323]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Ship className="w-6 h-6 text-[#0A3323]" />
                    </div>
                    <div>
                      <h4 className="text-lg text-[#0A3323] mb-1">
                        {departure.boatName}
                      </h4>
                      <div className="flex items-center gap-2 text-sm text-[#0A3323]/70">
                        <MapPin className="w-4 h-4" />
                        <span>
                          {departure.route.from} → {departure.route.to}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div
                    className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs border ${getStatusColor(
                      departure.status
                    )}`}
                  >
                    {getStatusIcon(departure.status)}
                    <span>{departure.status}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-[#0A3323]/10">
                  <div className="flex items-center gap-2 text-[#0A3323]/70">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">Departs: {departure.departure}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-[#FF6B35]" />
                    <span className="text-lg text-[#0A3323]">{departure.price}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default RiverLogistics;
