import HeroSection from './components/HeroSection';
import AIAssistant from './components/AIAssistant';
import RiverLogistics from './components/RiverLogistics';
import ExperiencesMarketplace from './components/ExperiencesMarketplace';
import GastronomyCarousel from './components/GastronomyCarousel';
import SocialProof from './components/SocialProof';
import CulturalTimeline from './components/CulturalTimeline';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen w-full overflow-x-hidden bg-white">
      {/* Hero Section with Search */}
      <HeroSection />
      
      {/* AI Assistant - Overlaps Hero */}
      <AIAssistant />
      
      {/* River Logistics Section */}
      <RiverLogistics />
      
      {/* Premium Experiences Marketplace */}
      <ExperiencesMarketplace />
      
      {/* Gastronomy & Reservations */}
      <GastronomyCarousel />
      
      {/* Social Proof & Community */}
      <SocialProof />
      
      {/* Cultural Timeline */}
      <CulturalTimeline />
      
      {/* Footer */}
      <Footer />
    </div>
  );
}
