
  # Amazon Hub 360 Landing Page

  This is a code bundle for Amazon Hub 360 Landing Page. The original project is available at https://www.figma.com/design/9aXg52HMNY8rTsFo4hc9HX/Amazon-Hub-360-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  