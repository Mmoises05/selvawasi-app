
  # Landing Page for Amazon Hub 360

  This is a code bundle for Landing Page for Amazon Hub 360. The original project is available at https://www.figma.com/design/kTj7UPfavy1kfd5luBPCly/Landing-Page-for-Amazon-Hub-360.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  