import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { HomepageV2 } from './components/HomepageV2';
import { SearchResults } from './components/SearchResults';
import { BookingModal } from './components/BookingModal';
import { ExperienceDetail } from './components/ExperienceDetail';
import { RestaurantModal } from './components/RestaurantModal';

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [isRestaurantModalOpen, setIsRestaurantModalOpen] = useState(false);
  const [selectedBoat, setSelectedBoat] = useState<string | null>(null);

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectBoat = (boatId: string) => {
    setSelectedBoat(boatId);
    setIsBookingModalOpen(true);
  };

  const boatInfo = {
    operator: 'Rio Express',
    route: 'Iquitos → Santa Rosa',
    departure: '08:00 AM',
    price: 65
  };

  const restaurantInfo = {
    name: 'El Dorado Amazónico',
    cuisine: 'Contemporary Peruvian & River Fish',
    image: 'https://images.unsplash.com/photo-1649039721832-016222650b4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxQZXJ1dmlhbiUyMGN1aXNpbmUlMjBmb29kfGVufDF8fHx8MTc2NzgwNzI3N3ww&ixlib=rb-4.1.0&q=80&w=1080'
  };

  return (
    <div className="min-h-screen" style={{ background: '#FAF8F3' }}>
      <Navigation currentPage={currentPage} onNavigate={handleNavigate} />
      
      {currentPage === 'home' && (
        <HomepageV2 onNavigate={handleNavigate} />
      )}
      
      {currentPage === 'transport' && (
        <SearchResults onSelectBoat={handleSelectBoat} />
      )}
      
      {currentPage === 'experiences' && (
        <ExperienceDetail />
      )}

      {currentPage === 'restaurants' && (
        <div className="pt-24">
          <div className="max-w-[1440px] mx-auto px-12 py-20">
            <h1 className="text-5xl font-bold mb-8" style={{ color: '#1B4332' }}>
              Restaurants & Dining
            </h1>
            <div className="grid grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="card-premium overflow-hidden cursor-pointer" onClick={() => setIsRestaurantModalOpen(true)}>
                  <div className="h-64">
                    <img 
                      src="https://images.unsplash.com/photo-1649039721832-016222650b4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxQZXJ1dmlhbiUyMGN1aXNpbmUlMjBmb29kfGVufDF8fHx8MTc2NzgwNzI3N3ww&ixlib=rb-4.1.0&q=80&w=1080"
                      alt="Restaurant"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2" style={{ color: '#1B4332' }}>
                      El Dorado Amazónico
                    </h3>
                    <p style={{ color: '#666' }}>Contemporary Peruvian & River Fish</p>
                    <button 
                      className="mt-4 w-full py-3 rounded-full font-semibold text-white"
                      style={{ background: 'linear-gradient(135deg, #FF4500 0%, #FF6347 100%)' }}
                    >
                      Reserve Table
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        boatInfo={boatInfo}
      />

      <RestaurantModal
        isOpen={isRestaurantModalOpen}
        onClose={() => setIsRestaurantModalOpen(false)}
        restaurant={restaurantInfo}
      />

      {/* Floating Action Button - Demo Navigation */}
      <div className="fixed bottom-8 right-8 z-40">
        <div className="card-premium p-4 shadow-soft-xl">
          <p className="text-xs font-semibold mb-3" style={{ color: '#1B4332' }}>Quick Nav</p>
          <div className="flex flex-col gap-2">
            <button
              onClick={() => handleNavigate('home')}
              className={`px-4 py-2 rounded-lg text-xs font-medium transition-all ${
                currentPage === 'home' ? 'text-white' : 'hover:bg-[#F5F5DC]'
              }`}
              style={currentPage === 'home' ? { background: 'linear-gradient(135deg, #00A86B 0%, #2E8B57 100%)' } : { color: '#1B4332' }}
            >
              Home
            </button>
            <button
              onClick={() => handleNavigate('transport')}
              className={`px-4 py-2 rounded-lg text-xs font-medium transition-all ${
                currentPage === 'transport' ? 'text-white' : 'hover:bg-[#F5F5DC]'
              }`}
              style={currentPage === 'transport' ? { background: 'linear-gradient(135deg, #00A86B 0%, #2E8B57 100%)' } : { color: '#1B4332' }}
            >
              Transport
            </button>
            <button
              onClick={() => handleNavigate('experiences')}
              className={`px-4 py-2 rounded-lg text-xs font-medium transition-all ${
                currentPage === 'experiences' ? 'text-white' : 'hover:bg-[#F5F5DC]'
              }`}
              style={currentPage === 'experiences' ? { background: 'linear-gradient(135deg, #00A86B 0%, #2E8B57 100%)' } : { color: '#1B4332' }}
            >
              Experience Detail
            </button>
            <button
              onClick={() => setIsBookingModalOpen(true)}
              className="px-4 py-2 rounded-lg text-xs font-medium hover:bg-[#F5F5DC] transition-all"
              style={{ color: '#1B4332' }}
            >
              Booking Modal
            </button>
            <button
              onClick={() => setIsRestaurantModalOpen(true)}
              className="px-4 py-2 rounded-lg text-xs font-medium hover:bg-[#F5F5DC] transition-all"
              style={{ color: '#1B4332' }}
            >
              Restaurant Modal
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
