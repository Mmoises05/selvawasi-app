import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Clock, DollarSign, Users, ChevronRight, AlertCircle, Anchor } from 'lucide-react';

interface SearchResultsProps {
  onSelectBoat?: (boatId: string) => void;
}

export function SearchResults({ onSelectBoat }: SearchResultsProps) {
  const [priceRange, setPriceRange] = useState([0, 200]);
  const [selectedTime, setSelectedTime] = useState<string[]>([]);
  const [selectedBoatType, setSelectedBoatType] = useState<string[]>([]);

  const timeSlots = ['Morning (6AM-12PM)', 'Afternoon (12PM-6PM)', 'Evening (6PM-12AM)'];
  const boatTypes = ['Rápido', 'Lancha Estándar', 'Ferry'];
  const operators = ['Rio Express', 'Amazon Navigator', 'Selva Cruises', 'Iquitos Marine'];

  const boats = [
    {
      id: '1',
      operator: 'Rio Express',
      boatType: 'Rápido',
      departure: '08:00 AM',
      arrival: '11:30 AM',
      duration: '3h 30m',
      price: 65,
      status: 'On Time',
      capacity: 45,
      available: 12
    },
    {
      id: '2',
      operator: 'Amazon Navigator',
      boatType: 'Lancha Estándar',
      departure: '10:00 AM',
      arrival: '02:45 PM',
      duration: '4h 45m',
      price: 45,
      status: 'Boarding',
      capacity: 60,
      available: 8
    },
    {
      id: '3',
      operator: 'Selva Cruises',
      boatType: 'Ferry',
      departure: '12:30 PM',
      arrival: '05:00 PM',
      duration: '4h 30m',
      price: 55,
      status: 'On Time',
      capacity: 80,
      available: 25
    },
    {
      id: '4',
      operator: 'Iquitos Marine',
      boatType: 'Rápido',
      departure: '02:00 PM',
      arrival: '05:15 PM',
      duration: '3h 15m',
      price: 70,
      status: 'Delayed',
      capacity: 40,
      available: 15
    },
    {
      id: '5',
      operator: 'Rio Express',
      boatType: 'Lancha Estándar',
      departure: '04:30 PM',
      arrival: '09:00 PM',
      duration: '4h 30m',
      price: 50,
      status: 'On Time',
      capacity: 55,
      available: 30
    }
  ];

  const statusColors: Record<string, { bg: string; text: string; border: string }> = {
    'On Time': { bg: '#E8F5E9', text: '#2E7D32', border: '#81C784' },
    'Boarding': { bg: '#FFF3E0', text: '#E65100', border: '#FFB74D' },
    'Delayed': { bg: '#FFEBEE', text: '#C62828', border: '#E57373' }
  };

  return (
    <div className="min-h-screen pt-24 pb-12" style={{ background: '#FAF8F3' }}>
      <div className="max-w-[1440px] mx-auto px-12">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-3" style={{ color: '#00A86B' }}>
            <Anchor className="w-5 h-5" />
            <span className="text-sm font-semibold">River Transport</span>
          </div>
          <h1 className="text-4xl font-bold mb-2" style={{ color: '#1B4332' }}>
            Iquitos → Santa Rosa
          </h1>
          <p className="text-lg" style={{ color: '#666' }}>
            Found {boats.length} available boats • January 8, 2026
          </p>
        </div>

        <div className="grid grid-cols-12 gap-8">
          {/* Left Sidebar - Filters */}
          <div className="col-span-3">
            <div className="card-premium p-6 sticky top-28">
              <h3 className="text-lg font-bold mb-6" style={{ color: '#1B4332' }}>Filters</h3>

              {/* Price Range */}
              <div className="mb-8">
                <label className="block text-sm font-semibold mb-4" style={{ color: '#1B4332' }}>
                  Price Range
                </label>
                <div className="px-2">
                  <input
                    type="range"
                    min="0"
                    max="200"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([0, parseInt(e.target.value)])}
                    className="w-full h-2 rounded-lg appearance-none cursor-pointer"
                    style={{ 
                      background: `linear-gradient(to right, #00A86B 0%, #00A86B ${(priceRange[1]/200)*100}%, #E8E6E1 ${(priceRange[1]/200)*100}%, #E8E6E1 100%)`
                    }}
                  />
                  <div className="flex justify-between mt-3">
                    <span className="text-sm font-medium" style={{ color: '#FF4500' }}>${priceRange[0]}</span>
                    <span className="text-sm font-medium" style={{ color: '#FF4500' }}>${priceRange[1]}</span>
                  </div>
                </div>
              </div>

              {/* Departure Time */}
              <div className="mb-8">
                <label className="block text-sm font-semibold mb-4" style={{ color: '#1B4332' }}>
                  Departure Time
                </label>
                <div className="space-y-2">
                  {timeSlots.map((slot) => (
                    <button
                      key={slot}
                      onClick={() => {
                        setSelectedTime(prev => 
                          prev.includes(slot) 
                            ? prev.filter(s => s !== slot)
                            : [...prev, slot]
                        );
                      }}
                      className={`w-full px-4 py-3 rounded-xl text-sm font-medium transition-all duration-300 ${
                        selectedTime.includes(slot)
                          ? 'text-white shadow-soft'
                          : 'bg-[#F5F5DC] hover:bg-[#E8E6E1]'
                      }`}
                      style={selectedTime.includes(slot) ? { background: 'linear-gradient(135deg, #00A86B 0%, #2E8B57 100%)' } : { color: '#1B4332' }}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              {/* Boat Type */}
              <div className="mb-8">
                <label className="block text-sm font-semibold mb-4" style={{ color: '#1B4332' }}>
                  Boat Type
                </label>
                <div className="space-y-2">
                  {boatTypes.map((type) => (
                    <button
                      key={type}
                      onClick={() => {
                        setSelectedBoatType(prev => 
                          prev.includes(type) 
                            ? prev.filter(t => t !== type)
                            : [...prev, type]
                        );
                      }}
                      className={`w-full px-4 py-3 rounded-xl text-sm font-medium transition-all duration-300 ${
                        selectedBoatType.includes(type)
                          ? 'text-white shadow-soft'
                          : 'bg-[#F5F5DC] hover:bg-[#E8E6E1]'
                      }`}
                      style={selectedBoatType.includes(type) ? { background: 'linear-gradient(135deg, #00A86B 0%, #2E8B57 100%)' } : { color: '#1B4332' }}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Operators */}
              <div>
                <label className="block text-sm font-semibold mb-4" style={{ color: '#1B4332' }}>
                  Operator
                </label>
                <div className="space-y-3">
                  {operators.map((operator) => (
                    <label key={operator} className="flex items-center gap-3 cursor-pointer group">
                      <input
                        type="checkbox"
                        className="w-5 h-5 rounded border-2 cursor-pointer"
                        style={{ borderColor: '#E8E6E1', accentColor: '#00A86B' }}
                      />
                      <span className="text-sm group-hover:text-[#00A86B] transition-colors" style={{ color: '#1B4332' }}>
                        {operator}
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Main Results Area */}
          <div className="col-span-9">
            <div className="space-y-4">
              {boats.map((boat, index) => (
                <motion.div
                  key={boat.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="card-premium p-6 hover:shadow-soft-xl transition-all duration-300"
                >
                  <div className="flex items-start justify-between">
                    {/* Left: Boat Info */}
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-4">
                        <h3 className="text-xl font-bold" style={{ color: '#1B4332' }}>
                          {boat.operator}
                        </h3>
                        <span 
                          className="px-3 py-1 rounded-full text-xs font-semibold border"
                          style={{
                            backgroundColor: statusColors[boat.status].bg,
                            color: statusColors[boat.status].text,
                            borderColor: statusColors[boat.status].border
                          }}
                        >
                          {boat.status}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 mb-6">
                        <span 
                          className="px-3 py-1 rounded-lg text-xs font-medium"
                          style={{ backgroundColor: '#F5F5DC', color: '#00A86B' }}
                        >
                          {boat.boatType}
                        </span>
                        {boat.available < 10 && (
                          <span className="flex items-center gap-1 text-xs font-medium" style={{ color: '#FF4500' }}>
                            <AlertCircle className="w-3.5 h-3.5" />
                            Only {boat.available} seats left
                          </span>
                        )}
                      </div>

                      {/* Time Info */}
                      <div className="flex items-center gap-8">
                        <div>
                          <div className="text-2xl font-bold mb-1" style={{ color: '#1B4332' }}>
                            {boat.departure}
                          </div>
                          <div className="text-sm" style={{ color: '#666' }}>Iquitos</div>
                        </div>

                        <div className="flex-1 flex flex-col items-center">
                          <div className="w-full h-px" style={{ backgroundColor: '#E8E6E1' }}></div>
                          <div className="flex items-center gap-2 mt-2">
                            <Clock className="w-4 h-4" style={{ color: '#00A86B' }} />
                            <span className="text-sm font-medium" style={{ color: '#00A86B' }}>
                              {boat.duration}
                            </span>
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="text-2xl font-bold mb-1" style={{ color: '#1B4332' }}>
                            {boat.arrival}
                          </div>
                          <div className="text-sm" style={{ color: '#666' }}>Santa Rosa</div>
                        </div>
                      </div>

                      {/* Capacity */}
                      <div className="flex items-center gap-2 mt-4">
                        <Users className="w-4 h-4" style={{ color: '#666' }} />
                        <span className="text-sm" style={{ color: '#666' }}>
                          {boat.available} of {boat.capacity} seats available
                        </span>
                      </div>
                    </div>

                    {/* Right: Price & CTA */}
                    <div className="flex flex-col items-end justify-between h-full ml-8">
                      <div className="text-right mb-6">
                        <div className="text-3xl font-bold mb-1" style={{ color: '#FF4500' }}>
                          ${boat.price}
                        </div>
                        <div className="text-sm" style={{ color: '#666' }}>per person</div>
                      </div>

                      <button
                        onClick={() => onSelectBoat?.(boat.id)}
                        className="px-8 py-4 rounded-full font-semibold text-white flex items-center gap-2 transition-all duration-300 hover:shadow-lg hover:scale-105"
                        style={{ background: 'linear-gradient(135deg, #FF4500 0%, #FF6347 100%)' }}
                      >
                        Select Seat
                        <ChevronRight className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
