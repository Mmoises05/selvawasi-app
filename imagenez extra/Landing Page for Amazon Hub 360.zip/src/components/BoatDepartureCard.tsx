import React from 'react';
import { motion } from 'motion/react';
import { Clock, DollarSign } from 'lucide-react';

interface BoatDepartureCardProps {
  boatName: string;
  route: string;
  status: 'On Time' | 'Delayed' | 'Boarding';
  departureTime: string;
  price: number;
}

export function BoatDepartureCard({ 
  boatName, 
  route, 
  status, 
  departureTime, 
  price 
}: BoatDepartureCardProps) {
  const statusColors = {
    'On Time': 'bg-green-500',
    'Delayed': 'bg-red-500',
    'Boarding': 'bg-[#FF6B35]'
  };
  
  return (
    <motion.div 
      className="glass-dark rounded-2xl p-6 text-white hover:scale-105 transition-transform duration-300"
      whileHover={{ y: -4 }}
    >
      <div className="flex items-start justify-between mb-4">
        <div>
          <h4 className="text-lg font-semibold mb-1">{boatName}</h4>
          <p className="text-sm text-[#E8DCCA]">{route}</p>
        </div>
        <div className={`${statusColors[status]} px-3 py-1 rounded-full text-xs font-medium`}>
          {status}
        </div>
      </div>
      
      <div className="flex items-center justify-between pt-4 border-t border-white/20">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-[#E8DCCA]" />
          <span className="text-sm">{departureTime}</span>
        </div>
        <div className="flex items-center gap-2">
          <DollarSign className="w-4 h-4 text-[#FF6B35]" />
          <span className="text-lg font-bold">{price}</span>
        </div>
      </div>
    </motion.div>
  );
}
