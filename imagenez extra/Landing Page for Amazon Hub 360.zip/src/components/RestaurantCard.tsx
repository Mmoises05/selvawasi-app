import React from 'react';
import { MapPin, Calendar } from 'lucide-react';
import { Button } from './Button';

interface RestaurantCardProps {
  image: string;
  name: string;
  cuisine: string;
  location: string;
}

export function RestaurantCard({ image, name, cuisine, location }: RestaurantCardProps) {
  return (
    <div className="min-w-[320px] bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={image} 
          alt={name}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
      </div>
      
      <div className="p-5">
        <h4 className="text-xl font-semibold text-[#0A3323] mb-2">{name}</h4>
        <p className="text-sm text-gray-600 mb-3">{cuisine}</p>
        
        <div className="flex items-center gap-2 mb-4 text-sm text-gray-500">
          <MapPin className="w-4 h-4" />
          <span>{location}</span>
        </div>
        
        <Button variant="primary" size="sm" className="w-full">
          <Calendar className="w-4 h-4 mr-2" />
          Reserve Table
        </Button>
      </div>
    </div>
  );
}
