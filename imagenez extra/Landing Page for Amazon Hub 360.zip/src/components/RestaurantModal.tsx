import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Calendar, Clock, Users, Plus, Minus, MessageSquare } from 'lucide-react';

interface RestaurantModalProps {
  isOpen: boolean;
  onClose: () => void;
  restaurant?: {
    name: string;
    cuisine: string;
    image: string;
  };
}

export function RestaurantModal({ isOpen, onClose, restaurant }: RestaurantModalProps) {
  const [selectedDate, setSelectedDate] = useState('2026-01-08');
  const [selectedTime, setSelectedTime] = useState('19:00');
  const [guests, setGuests] = useState(2);
  const [specialRequests, setSpecialRequests] = useState('');

  const timeSlots = [
    '17:00', '17:30', '18:00', '18:30', '19:00', '19:30',
    '20:00', '20:30', '21:00', '21:30', '22:00'
  ];

  const availableSlots = ['17:30', '18:00', '19:00', '19:30', '20:30', '21:00'];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-2xl"
            style={{ borderRadius: '24px', boxShadow: '0 24px 64px rgba(0, 0, 0, 0.2)' }}
          >
            {/* Header with Image */}
            <div className="relative h-48 rounded-t-3xl overflow-hidden">
              <img
                src={restaurant?.image || 'https://images.unsplash.com/photo-1649039721832-016222650b4d'}
                alt={restaurant?.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div>
              
              {/* Close Button */}
              <button
                onClick={onClose}
                className="absolute top-4 right-4 w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110"
                style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)' }}
              >
                <X className="w-6 h-6" style={{ color: '#1B4332' }} />
              </button>

              {/* Restaurant Info */}
              <div className="absolute bottom-4 left-6">
                <h2 className="text-2xl font-bold text-white mb-1">
                  {restaurant?.name || 'El Dorado Amazónico'}
                </h2>
                <p className="text-sm text-white/90">
                  {restaurant?.cuisine || 'Contemporary Peruvian & River Fish'}
                </p>
              </div>
            </div>

            {/* Content */}
            <div className="p-8" style={{ background: '#F5F5DC', borderBottomLeftRadius: '24px', borderBottomRightRadius: '24px' }}>
              {/* Date Selection */}
              <div className="mb-6">
                <label className="block text-sm font-semibold mb-3" style={{ color: '#1B4332' }}>
                  <Calendar className="w-4 h-4 inline mr-2" />
                  Select Date
                </label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  min="2026-01-08"
                  className="w-full px-4 py-4 rounded-xl border-2 transition-all duration-300"
                  style={{ borderColor: '#E8E6E1', backgroundColor: 'white' }}
                />
              </div>

              {/* Time Slots */}
              <div className="mb-6">
                <label className="block text-sm font-semibold mb-3" style={{ color: '#1B4332' }}>
                  <Clock className="w-4 h-4 inline mr-2" />
                  Choose Time
                </label>
                <div className="grid grid-cols-4 gap-3">
                  {timeSlots.map((time) => {
                    const isAvailable = availableSlots.includes(time);
                    const isSelected = selectedTime === time;
                    
                    return (
                      <button
                        key={time}
                        onClick={() => isAvailable && setSelectedTime(time)}
                        disabled={!isAvailable}
                        className={`py-3 rounded-xl font-medium transition-all duration-300 ${
                          !isAvailable 
                            ? 'opacity-40 cursor-not-allowed' 
                            : isSelected
                            ? 'text-white shadow-soft'
                            : 'hover:shadow-soft'
                        }`}
                        style={
                          isSelected
                            ? { background: 'linear-gradient(135deg, #00A86B 0%, #2E8B57 100%)' }
                            : { backgroundColor: 'white', color: '#1B4332', borderWidth: '2px', borderColor: '#E8E6E1' }
                        }
                      >
                        {time}
                      </button>
                    );
                  })}
                </div>
                <p className="text-xs mt-3" style={{ color: '#666' }}>
                  Available time slots are highlighted
                </p>
              </div>

              {/* Guest Selector */}
              <div className="mb-6">
                <label className="block text-sm font-semibold mb-3" style={{ color: '#1B4332' }}>
                  <Users className="w-4 h-4 inline mr-2" />
                  Number of Guests
                </label>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setGuests(Math.max(1, guests - 1))}
                    className="w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 hover:shadow-soft"
                    style={{ backgroundColor: 'white', color: '#1B4332' }}
                  >
                    <Minus className="w-5 h-5" />
                  </button>
                  
                  <div className="flex-1 text-center p-4 rounded-xl" style={{ backgroundColor: 'white' }}>
                    <div className="text-3xl font-bold" style={{ color: '#1B4332' }}>{guests}</div>
                    <div className="text-sm" style={{ color: '#666' }}>
                      {guests === 1 ? 'Guest' : 'Guests'}
                    </div>
                  </div>
                  
                  <button
                    onClick={() => setGuests(Math.min(10, guests + 1))}
                    className="w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 hover:shadow-soft"
                    style={{ backgroundColor: 'white', color: '#1B4332' }}
                  >
                    <Plus className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Special Requests */}
              <div className="mb-8">
                <label className="block text-sm font-semibold mb-3" style={{ color: '#1B4332' }}>
                  <MessageSquare className="w-4 h-4 inline mr-2" />
                  Special Requests (Optional)
                </label>
                <textarea
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  placeholder="e.g., Window seat, dietary restrictions, celebration occasion..."
                  rows={3}
                  className="w-full px-4 py-4 rounded-xl border-2 resize-none transition-all duration-300"
                  style={{ borderColor: '#E8E6E1', backgroundColor: 'white', color: '#1B4332' }}
                />
                <p className="text-xs mt-2" style={{ color: '#666' }}>
                  {specialRequests.length}/200 characters
                </p>
              </div>

              {/* Reservation Summary */}
              <div className="mb-6 p-5 rounded-2xl" style={{ background: 'linear-gradient(135deg, #E8F5E9 0%, rgba(245, 245, 220, 0.5) 100%)' }}>
                <h4 className="font-semibold mb-3 text-sm" style={{ color: '#1B4332' }}>
                  Reservation Summary
                </h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span style={{ color: '#666' }}>Restaurant</span>
                    <span className="font-medium" style={{ color: '#1B4332' }}>
                      {restaurant?.name || 'El Dorado Amazónico'}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span style={{ color: '#666' }}>Date</span>
                    <span className="font-medium" style={{ color: '#1B4332' }}>
                      {new Date(selectedDate).toLocaleDateString('en-US', { 
                        weekday: 'long', 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric' 
                      })}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span style={{ color: '#666' }}>Time</span>
                    <span className="font-medium" style={{ color: '#1B4332' }}>{selectedTime}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span style={{ color: '#666' }}>Party Size</span>
                    <span className="font-medium" style={{ color: '#1B4332' }}>
                      {guests} {guests === 1 ? 'Guest' : 'Guests'}
                    </span>
                  </div>
                </div>
              </div>

              {/* CTA Button */}
              <button
                onClick={onClose}
                className="w-full py-4 rounded-full font-bold text-white text-lg transition-all duration-300 hover:shadow-lg hover:scale-105"
                style={{ background: 'linear-gradient(135deg, #FF4500 0%, #FF6347 100%)' }}
              >
                Confirm Reservation
              </button>

              {/* Note */}
              <div className="mt-4 p-4 rounded-xl" style={{ backgroundColor: 'rgba(255, 215, 0, 0.1)', border: '1px solid #FFD700' }}>
                <p className="text-xs leading-relaxed" style={{ color: '#666' }}>
                  <strong style={{ color: '#1B4332' }}>Note:</strong> Your reservation will be confirmed within 2 hours. 
                  You'll receive a confirmation email and SMS with all the details.
                </p>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
