import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Calendar, User, Mail, Phone, CreditCard, Check, Armchair, Bed } from 'lucide-react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  boatInfo?: {
    operator: string;
    route: string;
    departure: string;
    price: number;
  };
}

export function BookingModal({ isOpen, onClose, boatInfo }: BookingModalProps) {
  const [step, setStep] = useState(1);
  const [seatType, setSeatType] = useState<'seat' | 'hammock'>('seat');
  const [selectedDate, setSelectedDate] = useState('2026-01-08');
  const [passengers, setPassengers] = useState(1);

  const seatPrices = {
    seat: boatInfo?.price || 65,
    hammock: (boatInfo?.price || 65) - 20
  };

  const totalPrice = seatPrices[seatType] * passengers;
  const tax = totalPrice * 0.18;
  const finalTotal = totalPrice + tax;

  const handleNext = () => {
    if (step < 3) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-3xl max-h-[90vh] overflow-y-auto scrollbar-custom"
            style={{ background: '#F5F5DC', borderRadius: '24px', boxShadow: '0 24px 64px rgba(0, 0, 0, 0.2)' }}
          >
            {/* Header */}
            <div className="sticky top-0 z-10 px-8 py-6 border-b flex items-center justify-between" style={{ background: 'white', borderColor: '#E8E6E1', borderTopLeftRadius: '24px', borderTopRightRadius: '24px' }}>
              <div>
                <h2 className="text-2xl font-bold mb-1" style={{ color: '#1B4332' }}>Book Your Journey</h2>
                <p className="text-sm" style={{ color: '#666' }}>
                  {boatInfo?.operator} • {boatInfo?.route}
                </p>
              </div>
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#F5F5DC] transition-colors"
              >
                <X className="w-6 h-6" style={{ color: '#1B4332' }} />
              </button>
            </div>

            {/* Progress Indicators */}
            <div className="px-8 py-6 flex items-center justify-center gap-3">
              {[1, 2, 3].map((s) => (
                <div key={s} className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all duration-300 ${
                      step >= s ? 'text-white' : 'bg-[#E8E6E1]'
                    }`}
                    style={step >= s ? { background: 'linear-gradient(135deg, #00A86B 0%, #2E8B57 100%)' } : { color: '#999' }}
                  >
                    {step > s ? <Check className="w-5 h-5" /> : s}
                  </div>
                  {s < 3 && (
                    <div className="w-16 h-1 rounded-full" style={{ background: step > s ? '#00A86B' : '#E8E6E1' }}></div>
                  )}
                </div>
              ))}
            </div>

            {/* Content */}
            <div className="px-8 py-6">
              {/* Step 1: Choose Date & Seat Type */}
              {step === 1 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <h3 className="text-xl font-bold mb-6" style={{ color: '#1B4332' }}>
                    Select Date & Seat Type
                  </h3>

                  {/* Date Picker */}
                  <div className="mb-8">
                    <label className="block text-sm font-semibold mb-3" style={{ color: '#1B4332' }}>
                      <Calendar className="w-4 h-4 inline mr-2" />
                      Travel Date
                    </label>
                    <input
                      type="date"
                      value={selectedDate}
                      onChange={(e) => setSelectedDate(e.target.value)}
                      className="w-full px-4 py-4 rounded-xl border-2 transition-all duration-300"
                      style={{ borderColor: '#E8E6E1', backgroundColor: 'white' }}
                    />
                  </div>

                  {/* Seat Type Selection */}
                  <div className="mb-8">
                    <label className="block text-sm font-semibold mb-3" style={{ color: '#1B4332' }}>
                      Seat Type
                    </label>
                    <div className="grid grid-cols-2 gap-4">
                      <button
                        onClick={() => setSeatType('seat')}
                        className={`p-6 rounded-2xl border-2 transition-all duration-300 ${
                          seatType === 'seat' ? 'shadow-soft-lg' : ''
                        }`}
                        style={{
                          borderColor: seatType === 'seat' ? '#00A86B' : '#E8E6E1',
                          backgroundColor: seatType === 'seat' ? '#E8F5E9' : 'white'
                        }}
                      >
                        <Armchair className="w-12 h-12 mx-auto mb-3" style={{ color: '#00A86B' }} />
                        <div className="text-lg font-bold mb-2" style={{ color: '#1B4332' }}>Regular Seat</div>
                        <div className="text-2xl font-bold" style={{ color: '#FF4500' }}>
                          ${seatPrices.seat}
                        </div>
                        <div className="text-xs mt-1" style={{ color: '#666' }}>per person</div>
                      </button>

                      <button
                        onClick={() => setSeatType('hammock')}
                        className={`p-6 rounded-2xl border-2 transition-all duration-300 ${
                          seatType === 'hammock' ? 'shadow-soft-lg' : ''
                        }`}
                        style={{
                          borderColor: seatType === 'hammock' ? '#00A86B' : '#E8E6E1',
                          backgroundColor: seatType === 'hammock' ? '#E8F5E9' : 'white'
                        }}
                      >
                        <Bed className="w-12 h-12 mx-auto mb-3" style={{ color: '#00A86B' }} />
                        <div className="text-lg font-bold mb-2" style={{ color: '#1B4332' }}>Hammock</div>
                        <div className="text-2xl font-bold" style={{ color: '#FF4500' }}>
                          ${seatPrices.hammock}
                        </div>
                        <div className="text-xs mt-1" style={{ color: '#666' }}>per person</div>
                      </button>
                    </div>
                  </div>

                  {/* Number of Passengers */}
                  <div>
                    <label className="block text-sm font-semibold mb-3" style={{ color: '#1B4332' }}>
                      Number of Passengers
                    </label>
                    <div className="flex items-center gap-4">
                      <button
                        onClick={() => setPassengers(Math.max(1, passengers - 1))}
                        className="w-12 h-12 rounded-full flex items-center justify-center font-bold text-xl transition-all duration-300 hover:shadow-soft"
                        style={{ backgroundColor: '#F5F5DC', color: '#1B4332' }}
                      >
                        −
                      </button>
                      <div className="flex-1 text-center">
                        <div className="text-3xl font-bold" style={{ color: '#1B4332' }}>{passengers}</div>
                        <div className="text-sm" style={{ color: '#666' }}>
                          {passengers === 1 ? 'Passenger' : 'Passengers'}
                        </div>
                      </div>
                      <button
                        onClick={() => setPassengers(passengers + 1)}
                        className="w-12 h-12 rounded-full flex items-center justify-center font-bold text-xl transition-all duration-300 hover:shadow-soft"
                        style={{ backgroundColor: '#F5F5DC', color: '#1B4332' }}
                      >
                        +
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 2: Passenger Details */}
              {step === 2 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <h3 className="text-xl font-bold mb-6" style={{ color: '#1B4332' }}>
                    Passenger Information
                  </h3>

                  <div className="space-y-5">
                    <div>
                      <label className="block text-sm font-semibold mb-2" style={{ color: '#1B4332' }}>
                        <User className="w-4 h-4 inline mr-2" />
                        Full Name
                      </label>
                      <input
                        type="text"
                        placeholder="Enter full name as per ID"
                        className="w-full px-4 py-4 rounded-xl border-2 transition-all duration-300"
                        style={{ borderColor: '#E8E6E1', backgroundColor: 'white' }}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold mb-2" style={{ color: '#1B4332' }}>
                        ID / Passport Number
                      </label>
                      <input
                        type="text"
                        placeholder="Enter ID or Passport number"
                        className="w-full px-4 py-4 rounded-xl border-2 transition-all duration-300"
                        style={{ borderColor: '#E8E6E1', backgroundColor: 'white' }}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold mb-2" style={{ color: '#1B4332' }}>
                        <Mail className="w-4 h-4 inline mr-2" />
                        Email Address
                      </label>
                      <input
                        type="email"
                        placeholder="your.email@example.com"
                        className="w-full px-4 py-4 rounded-xl border-2 transition-all duration-300"
                        style={{ borderColor: '#E8E6E1', backgroundColor: 'white' }}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold mb-2" style={{ color: '#1B4332' }}>
                        <Phone className="w-4 h-4 inline mr-2" />
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        placeholder="+51 xxx xxx xxx"
                        className="w-full px-4 py-4 rounded-xl border-2 transition-all duration-300"
                        style={{ borderColor: '#E8E6E1', backgroundColor: 'white' }}
                      />
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 3: Summary & Payment */}
              {step === 3 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <h3 className="text-xl font-bold mb-6" style={{ color: '#1B4332' }}>
                    Payment & Summary
                  </h3>

                  {/* Booking Summary */}
                  <div className="mb-6 p-6 rounded-2xl" style={{ backgroundColor: 'white' }}>
                    <h4 className="font-semibold mb-4" style={{ color: '#1B4332' }}>Booking Summary</h4>
                    <div className="space-y-3 mb-4 pb-4 border-b" style={{ borderColor: '#E8E6E1' }}>
                      <div className="flex justify-between text-sm">
                        <span style={{ color: '#666' }}>Route</span>
                        <span className="font-medium" style={{ color: '#1B4332' }}>{boatInfo?.route}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span style={{ color: '#666' }}>Date</span>
                        <span className="font-medium" style={{ color: '#1B4332' }}>{selectedDate}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span style={{ color: '#666' }}>Departure</span>
                        <span className="font-medium" style={{ color: '#1B4332' }}>{boatInfo?.departure}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span style={{ color: '#666' }}>Seat Type</span>
                        <span className="font-medium capitalize" style={{ color: '#1B4332' }}>{seatType}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span style={{ color: '#666' }}>Passengers</span>
                        <span className="font-medium" style={{ color: '#1B4332' }}>{passengers}</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span style={{ color: '#666' }}>Subtotal</span>
                        <span className="font-medium" style={{ color: '#1B4332' }}>${totalPrice.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span style={{ color: '#666' }}>Tax (18%)</span>
                        <span className="font-medium" style={{ color: '#1B4332' }}>${tax.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between pt-3 border-t text-lg font-bold" style={{ borderColor: '#E8E6E1' }}>
                        <span style={{ color: '#1B4332' }}>Total</span>
                        <span style={{ color: '#FF4500' }}>${finalTotal.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Payment Method */}
                  <div>
                    <label className="block text-sm font-semibold mb-3" style={{ color: '#1B4332' }}>
                      <CreditCard className="w-4 h-4 inline mr-2" />
                      Payment Method
                    </label>
                    <div className="space-y-3">
                      <div className="p-4 rounded-xl border-2 cursor-pointer hover:shadow-soft transition-all duration-300" style={{ borderColor: '#00A86B', backgroundColor: '#E8F5E9' }}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-5 h-5 rounded-full border-4" style={{ borderColor: '#00A86B', backgroundColor: '#00A86B' }}></div>
                            <span className="font-medium" style={{ color: '#1B4332' }}>Credit / Debit Card</span>
                          </div>
                          <div className="flex gap-2">
                            <div className="w-10 h-6 rounded bg-gradient-to-r from-blue-600 to-blue-400"></div>
                            <div className="w-10 h-6 rounded bg-gradient-to-r from-orange-600 to-orange-400"></div>
                          </div>
                        </div>
                      </div>
                      <div className="p-4 rounded-xl border-2 cursor-pointer hover:bg-white transition-all duration-300" style={{ borderColor: '#E8E6E1' }}>
                        <div className="flex items-center gap-3">
                          <div className="w-5 h-5 rounded-full border-2" style={{ borderColor: '#E8E6E1' }}></div>
                          <span className="font-medium" style={{ color: '#1B4332' }}>PayPal</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </div>

            {/* Footer Actions */}
            <div className="sticky bottom-0 px-8 py-6 border-t flex items-center justify-between" style={{ background: 'white', borderColor: '#E8E6E1', borderBottomLeftRadius: '24px', borderBottomRightRadius: '24px' }}>
              {step > 1 && (
                <button
                  onClick={handleBack}
                  className="px-6 py-3 rounded-full font-semibold transition-all duration-300 hover:bg-[#E8E6E1]"
                  style={{ color: '#1B4332' }}
                >
                  Back
                </button>
              )}
              <div className="flex-1"></div>
              <button
                onClick={step === 3 ? onClose : handleNext}
                className="px-8 py-4 rounded-full font-semibold text-white transition-all duration-300 hover:shadow-lg"
                style={{ background: 'linear-gradient(135deg, #FF4500 0%, #FF6347 100%)' }}
              >
                {step === 3 ? 'Pay Now' : 'Continue'}
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
