import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Star, MapPin, Clock, Users, Wifi, UtensilsCrossed, 
  Globe, Camera, ChevronDown, ChevronUp, Calendar,
  Minus, Plus
} from 'lucide-react';

export function ExperienceDetail() {
  const [expandedDay, setExpandedDay] = useState<number | null>(1);
  const [selectedDate, setSelectedDate] = useState('2026-01-15');
  const [guests, setGuests] = useState(2);

  const amenities = [
    { icon: Wifi, label: 'WiFi' },
    { icon: UtensilsCrossed, label: 'All Meals' },
    { icon: Users, label: 'Expert Guide' },
    { icon: Camera, label: 'Photo Tours' },
    { icon: Globe, label: 'Transfers' },
  ];

  const itinerary = [
    {
      day: 1,
      title: 'Arrival & Welcome',
      activities: [
        'Pick-up from Iquitos airport',
        'Boat transfer to eco-lodge (1.5 hours)',
        'Welcome drink & orientation',
        'Sunset wildlife spotting cruise',
        'Traditional Amazonian dinner'
      ]
    },
    {
      day: 2,
      title: 'Jungle Exploration',
      activities: [
        'Dawn bird watching expedition',
        'Rainforest canopy walk',
        'Visit indigenous community',
        'Piranha fishing experience',
        'Night safari spotting nocturnal animals'
      ]
    },
    {
      day: 3,
      title: 'River & Wildlife',
      activities: [
        'Pink dolphin encounter',
        'Kayaking through flooded forests',
        'Medicinal plants workshop',
        'Cooking class with local chef',
        'Cultural dance performance'
      ]
    },
    {
      day: 4,
      title: 'Departure',
      activities: [
        'Early morning monkey spotting',
        'Farewell breakfast',
        'Check-out and boat transfer',
        'Return to Iquitos airport'
      ]
    }
  ];

  return (
    <div className="min-h-screen pt-24 pb-12" style={{ background: '#FAF8F3' }}>
      <div className="max-w-[1440px] mx-auto px-12">
        {/* Hero Section */}
        <div className="mb-12">
          <div className="relative h-[500px] rounded-3xl overflow-hidden shadow-soft-xl mb-8">
            <img
              src="https://images.unsplash.com/photo-1752769041878-f24e37fd6aea?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBlY28lMjByZXNvcnQlMjBpbnRlcmlvcnxlbnwxfHx8fDE3Njc4ODY4Nzl8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Luxury Amazon Eco-Lodge"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
            <div className="absolute bottom-8 left-8 right-8">
              <div className="flex items-center gap-2 mb-3">
                <span 
                  className="px-3 py-1 rounded-full text-xs font-semibold"
                  style={{ backgroundColor: 'rgba(255, 69, 0, 0.9)', color: 'white' }}
                >
                  FEATURED
                </span>
                <span 
                  className="px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1"
                  style={{ backgroundColor: 'rgba(255, 215, 0, 0.9)', color: '#1B4332' }}
                >
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#FF4500' }}></div>
                  360° View Available
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-8">
          {/* Main Content */}
          <div className="col-span-8">
            {/* Header Info */}
            <div className="mb-8">
              <h1 className="text-4xl font-bold mb-4" style={{ color: '#1B4332' }}>
                Luxury Amazon Eco-Lodge Experience
              </h1>
              
              <div className="flex items-center gap-6 mb-4">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" style={{ color: '#FFD700' }} />
                  ))}
                  <span className="ml-2 font-semibold" style={{ color: '#1B4332' }}>4.9</span>
                  <span style={{ color: '#666' }}>(127 reviews)</span>
                </div>
                <div className="flex items-center gap-2" style={{ color: '#666' }}>
                  <MapPin className="w-5 h-5" />
                  <span>Pacaya Samiria Reserve, Iquitos</span>
                </div>
              </div>

              <div className="flex items-center gap-8">
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5" style={{ color: '#00A86B' }} />
                  <span className="font-medium" style={{ color: '#1B4332' }}>4 Days / 3 Nights</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5" style={{ color: '#00A86B' }} />
                  <span className="font-medium" style={{ color: '#1B4332' }}>Max 12 guests</span>
                </div>
              </div>
            </div>

            {/* About */}
            <div className="card-premium p-8 mb-8">
              <h3 className="text-2xl font-bold mb-4" style={{ color: '#1B4332' }}>About This Experience</h3>
              <p className="leading-relaxed mb-4" style={{ color: '#666' }}>
                Immerse yourself in the breathtaking beauty of the Amazon rainforest at our award-winning eco-lodge. 
                Nestled deep within the Pacaya Samiria National Reserve, this luxury retreat offers an unparalleled 
                blend of adventure and comfort.
              </p>
              <p className="leading-relaxed" style={{ color: '#666' }}>
                Wake up to the sounds of howler monkeys, explore pristine rainforest trails with expert naturalist guides, 
                encounter pink river dolphins, and enjoy gourmet cuisine prepared with local ingredients. Our sustainable 
                lodge features elegant bungalows with private balconies overlooking the river, ensuring your Amazon 
                adventure is as comfortable as it is unforgettable.
              </p>
            </div>

            {/* Amenities */}
            <div className="card-premium p-8 mb-8">
              <h3 className="text-2xl font-bold mb-6" style={{ color: '#1B4332' }}>What's Included</h3>
              <div className="grid grid-cols-5 gap-6">
                {amenities.map((amenity, index) => (
                  <div key={index} className="flex flex-col items-center text-center">
                    <div 
                      className="w-16 h-16 rounded-2xl flex items-center justify-center mb-3 transition-all duration-300 hover:scale-110"
                      style={{ background: 'linear-gradient(135deg, #E8F5E9 0%, #F5F5DC 100%)' }}
                    >
                      <amenity.icon className="w-8 h-8" style={{ color: '#00A86B' }} />
                    </div>
                    <span className="text-sm font-medium" style={{ color: '#1B4332' }}>
                      {amenity.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Itinerary */}
            <div className="card-premium p-8">
              <h3 className="text-2xl font-bold mb-6" style={{ color: '#1B4332' }}>Detailed Itinerary</h3>
              <div className="space-y-4">
                {itinerary.map((day) => (
                  <div key={day.day} className="border-2 rounded-2xl overflow-hidden transition-all duration-300" style={{ borderColor: '#E8E6E1' }}>
                    <button
                      onClick={() => setExpandedDay(expandedDay === day.day ? null : day.day)}
                      className="w-full px-6 py-4 flex items-center justify-between hover:bg-[#F5F5DC] transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <div 
                          className="w-12 h-12 rounded-full flex items-center justify-center font-bold text-white"
                          style={{ background: 'linear-gradient(135deg, #00A86B 0%, #2E8B57 100%)' }}
                        >
                          {day.day}
                        </div>
                        <div className="text-left">
                          <div className="text-xs font-semibold mb-1" style={{ color: '#00A86B' }}>
                            DAY {day.day}
                          </div>
                          <div className="font-bold" style={{ color: '#1B4332' }}>{day.title}</div>
                        </div>
                      </div>
                      {expandedDay === day.day ? (
                        <ChevronUp className="w-5 h-5" style={{ color: '#00A86B' }} />
                      ) : (
                        <ChevronDown className="w-5 h-5" style={{ color: '#666' }} />
                      )}
                    </button>
                    
                    {expandedDay === day.day && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="px-6 pb-6"
                      >
                        <ul className="space-y-2 ml-16">
                          {day.activities.map((activity, index) => (
                            <li key={index} className="flex items-start gap-3">
                              <div className="w-2 h-2 rounded-full mt-2" style={{ backgroundColor: '#00A86B' }}></div>
                              <span style={{ color: '#666' }}>{activity}</span>
                            </li>
                          ))}
                        </ul>
                      </motion.div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Gallery Preview */}
            <div className="mt-8">
              <h3 className="text-2xl font-bold mb-6" style={{ color: '#1B4332' }}>Gallery</h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="aspect-square rounded-2xl overflow-hidden shadow-soft hover:shadow-soft-lg transition-all duration-300 cursor-pointer">
                  <img
                    src="https://images.unsplash.com/photo-1727815706353-790e0e298390?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBbWF6b24lMjB3aWxkbGlmZSUyMG1vbmtleXxlbnwxfHx8fDE3Njc4ODY4Nzl8MA&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Wildlife"
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                  />
                </div>
                <div className="aspect-square rounded-2xl overflow-hidden shadow-soft hover:shadow-soft-lg transition-all duration-300 cursor-pointer">
                  <img
                    src="https://images.unsplash.com/photo-1663409413785-439797d95360?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqdW5nbGUlMjBjYW5vcHklMjB3YWxrd2F5fGVufDF8fHx8MTc2Nzg4Njg4MHww&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Canopy Walk"
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                  />
                </div>
                <div className="aspect-square rounded-2xl overflow-hidden shadow-soft hover:shadow-soft-lg transition-all duration-300 cursor-pointer">
                  <img
                    src="https://images.unsplash.com/photo-1724637411073-35bebbca6a6e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBbWF6b24lMjByYWluZm9yZXN0JTIwbmF0dXJlfGVufDF8fHx8MTc2NzgwNzI3N3ww&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Rainforest"
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Sticky Booking Card */}
          <div className="col-span-4">
            <div className="sticky top-28">
              <div className="card-premium p-8">
                <div className="mb-6">
                  <div className="flex items-baseline gap-2 mb-2">
                    <span className="text-xs" style={{ color: '#666' }}>From</span>
                    <span className="text-4xl font-bold" style={{ color: '#FF4500' }}>$449</span>
                    <span style={{ color: '#666' }}>/ person</span>
                  </div>
                  <p className="text-sm" style={{ color: '#666' }}>4 days, 3 nights • All inclusive</p>
                </div>

                {/* Date Picker */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold mb-3" style={{ color: '#1B4332' }}>
                    <Calendar className="w-4 h-4 inline mr-2" />
                    Select Date
                  </label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    min="2026-01-08"
                    className="w-full px-4 py-4 rounded-xl border-2 transition-all duration-300"
                    style={{ borderColor: '#E8E6E1', backgroundColor: 'white' }}
                  />
                </div>

                {/* Guest Selector */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold mb-3" style={{ color: '#1B4332' }}>
                    <Users className="w-4 h-4 inline mr-2" />
                    Number of Guests
                  </label>
                  <div className="flex items-center justify-between p-4 rounded-xl border-2" style={{ borderColor: '#E8E6E1', backgroundColor: 'white' }}>
                    <button
                      onClick={() => setGuests(Math.max(1, guests - 1))}
                      className="w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 hover:shadow-soft"
                      style={{ backgroundColor: '#F5F5DC', color: '#1B4332' }}
                    >
                      <Minus className="w-5 h-5" />
                    </button>
                    <div className="text-center">
                      <div className="text-2xl font-bold" style={{ color: '#1B4332' }}>{guests}</div>
                      <div className="text-xs" style={{ color: '#666' }}>
                        {guests === 1 ? 'Guest' : 'Guests'}
                      </div>
                    </div>
                    <button
                      onClick={() => setGuests(Math.min(12, guests + 1))}
                      className="w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 hover:shadow-soft"
                      style={{ backgroundColor: '#F5F5DC', color: '#1B4332' }}
                    >
                      <Plus className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                {/* Price Breakdown */}
                <div className="mb-6 p-4 rounded-xl" style={{ backgroundColor: '#F5F5DC' }}>
                  <div className="flex justify-between mb-2">
                    <span style={{ color: '#666' }}>$449 × {guests} guest{guests > 1 ? 's' : ''}</span>
                    <span className="font-medium" style={{ color: '#1B4332' }}>${449 * guests}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span style={{ color: '#666' }}>Service fee</span>
                    <span className="font-medium" style={{ color: '#1B4332' }}>${(449 * guests * 0.1).toFixed(0)}</span>
                  </div>
                  <div className="pt-3 mt-3 border-t flex justify-between" style={{ borderColor: '#E8E6E1' }}>
                    <span className="font-bold" style={{ color: '#1B4332' }}>Total</span>
                    <span className="text-xl font-bold" style={{ color: '#FF4500' }}>
                      ${(449 * guests * 1.1).toFixed(0)}
                    </span>
                  </div>
                </div>

                {/* CTA Button */}
                <button
                  className="w-full py-4 rounded-full font-bold text-white text-lg transition-all duration-300 hover:shadow-lg hover:scale-105 mb-4"
                  style={{ background: 'linear-gradient(135deg, #FF4500 0%, #FF6347 100%)' }}
                >
                  Request Booking
                </button>

                <p className="text-xs text-center" style={{ color: '#666' }}>
                  You won't be charged yet
                </p>
              </div>

              {/* Trust Badges */}
              <div className="mt-6 p-6 rounded-2xl" style={{ backgroundColor: '#E8F5E9' }}>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: '#00A86B' }}>
                    <Star className="w-6 h-6 text-white fill-white" />
                  </div>
                  <div>
                    <div className="font-bold" style={{ color: '#1B4332' }}>Verified Eco-Tourism</div>
                    <div className="text-xs" style={{ color: '#666' }}>Certified sustainable lodge</div>
                  </div>
                </div>
                <p className="text-xs leading-relaxed" style={{ color: '#666' }}>
                  This experience supports local communities and follows strict environmental guidelines.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
