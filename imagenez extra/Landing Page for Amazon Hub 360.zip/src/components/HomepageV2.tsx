import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Ship, Compass, UtensilsCrossed, ArrowRight, Play } from 'lucide-react';

interface HomepageV2Props {
  onNavigate?: (page: string) => void;
}

export function HomepageV2({ onNavigate }: HomepageV2Props) {
  const [activeTab, setActiveTab] = useState<'transport' | 'experiences' | 'restaurants'>('transport');

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        {/* Background Image with Gradient Overlay */}
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1534861542011-27e852f7c9f5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBbWF6b24lMjByaXZlciUyMGFlcmlhbCUyMGRyb25lfGVufDF8fHx8MTc2NzgwNzI3N3ww&ixlib=rb-4.1.0&q=80&w=1080')`,
          }}
        >
          <div className="absolute inset-0" style={{
            background: 'linear-gradient(135deg, rgba(27, 67, 50, 0.7) 0%, rgba(0, 168, 107, 0.5) 50%, rgba(46, 139, 87, 0.6) 100%)'
          }}></div>
        </div>

        {/* Floating Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <motion.div
            animate={{ y: [0, -20, 0], opacity: [0.3, 0.5, 0.3] }}
            transition={{ duration: 6, repeat: Infinity }}
            className="absolute top-20 left-20 w-96 h-96 rounded-full blur-3xl"
            style={{ background: 'radial-gradient(circle, rgba(255, 215, 0, 0.3) 0%, transparent 70%)' }}
          ></motion.div>
          <motion.div
            animate={{ y: [0, 20, 0], opacity: [0.3, 0.5, 0.3] }}
            transition={{ duration: 8, repeat: Infinity, delay: 1 }}
            className="absolute bottom-20 right-20 w-96 h-96 rounded-full blur-3xl"
            style={{ background: 'radial-gradient(circle, rgba(255, 69, 0, 0.3) 0%, transparent 70%)' }}
          ></motion.div>
        </div>

        {/* Hero Content */}
        <motion.div 
          className="relative z-10 text-center px-4 max-w-6xl mx-auto"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mb-6"
          >
            <h1 className="text-7xl font-bold text-white mb-6 drop-shadow-2xl leading-tight">
              Discover the Magic<br />of Iquitos
            </h1>
            <p className="text-3xl font-medium mb-4" style={{ color: '#FFD700', textShadow: '0 2px 20px rgba(0,0,0,0.3)' }}>
              Navigate the Amazon
            </p>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Your gateway to river logistics, luxury eco-lodges, and authentic Amazonian experiences
            </p>
          </motion.div>

          {/* Unified Search Bar */}
          <motion.div 
            className="max-w-5xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <div className="card-premium p-3" style={{ backgroundColor: 'rgba(255, 255, 255, 0.98)' }}>
              {/* Tab Buttons */}
              <div className="flex gap-2 mb-4">
                <button
                  onClick={() => setActiveTab('transport')}
                  className={`flex-1 py-4 px-6 rounded-2xl transition-all duration-300 flex items-center justify-center gap-3 font-semibold ${
                    activeTab === 'transport' 
                      ? 'text-white shadow-soft-lg scale-105' 
                      : 'hover:bg-[#F5F5DC]'
                  }`}
                  style={activeTab === 'transport' 
                    ? { background: 'linear-gradient(135deg, #00A86B 0%, #2E8B57 100%)' }
                    : { color: '#1B4332' }
                  }
                >
                  <Ship className="w-5 h-5" />
                  <span>River Transport</span>
                </button>
                <button
                  onClick={() => setActiveTab('experiences')}
                  className={`flex-1 py-4 px-6 rounded-2xl transition-all duration-300 flex items-center justify-center gap-3 font-semibold ${
                    activeTab === 'experiences' 
                      ? 'text-white shadow-soft-lg scale-105' 
                      : 'hover:bg-[#F5F5DC]'
                  }`}
                  style={activeTab === 'experiences' 
                    ? { background: 'linear-gradient(135deg, #00A86B 0%, #2E8B57 100%)' }
                    : { color: '#1B4332' }
                  }
                >
                  <Compass className="w-5 h-5" />
                  <span>Experiences</span>
                </button>
                <button
                  onClick={() => setActiveTab('restaurants')}
                  className={`flex-1 py-4 px-6 rounded-2xl transition-all duration-300 flex items-center justify-center gap-3 font-semibold ${
                    activeTab === 'restaurants' 
                      ? 'text-white shadow-soft-lg scale-105' 
                      : 'hover:bg-[#F5F5DC]'
                  }`}
                  style={activeTab === 'restaurants' 
                    ? { background: 'linear-gradient(135deg, #00A86B 0%, #2E8B57 100%)' }
                    : { color: '#1B4332' }
                  }
                >
                  <UtensilsCrossed className="w-5 h-5" />
                  <span>Dining</span>
                </button>
              </div>
              
              {/* Search Input */}
              <div className="flex gap-3 bg-white rounded-2xl p-4 shadow-soft">
                <Search className="w-6 h-6 ml-2" style={{ color: '#00A86B' }} />
                <input
                  type="text"
                  placeholder={
                    activeTab === 'transport' 
                      ? 'Search routes, schedules, destinations...' 
                      : activeTab === 'experiences'
                      ? 'Search tours, lodges, adventures...'
                      : 'Search restaurants, cuisines, locations...'
                  }
                  className="flex-1 outline-none text-lg"
                  style={{ color: '#1B4332' }}
                />
                <button
                  onClick={() => activeTab === 'transport' && onNavigate?.('transport')}
                  className="px-8 py-4 rounded-xl font-bold text-white transition-all duration-300 hover:shadow-lg hover:scale-105"
                  style={{ background: 'linear-gradient(135deg, #FF4500 0%, #FF6347 100%)' }}
                >
                  Search
                </button>
              </div>
            </div>
          </motion.div>

          {/* Quick Stats */}
          <motion.div
            className="mt-12 flex items-center justify-center gap-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
          >
            <div className="text-center">
              <div className="text-4xl font-bold text-white mb-2">50+</div>
              <div className="text-sm text-white/80">Daily Departures</div>
            </div>
            <div className="w-px h-12 bg-white/30"></div>
            <div className="text-center">
              <div className="text-4xl font-bold text-white mb-2">120+</div>
              <div className="text-sm text-white/80">Experiences</div>
            </div>
            <div className="w-px h-12 bg-white/30"></div>
            <div className="text-center">
              <div className="text-4xl font-bold text-white mb-2">4.9★</div>
              <div className="text-sm text-white/80">Average Rating</div>
            </div>
          </motion.div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="w-8 h-12 rounded-full border-2 border-white/50 flex items-start justify-center p-2">
            <div className="w-1.5 h-3 rounded-full bg-white/70"></div>
          </div>
        </motion.div>
      </section>

      {/* Featured Sections */}
      <section className="py-20 px-12" style={{ background: 'linear-gradient(180deg, #FAF8F3 0%, #F5F5DC 100%)' }}>
        <div className="max-w-[1440px] mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-4" style={{ color: '#1B4332' }}>
              Why Choose Amazon Hub 360?
            </h2>
            <p className="text-xl" style={{ color: '#666' }}>
              Your all-in-one platform for exploring Iquitos
            </p>
          </div>

          <div className="grid grid-cols-3 gap-8">
            {/* Transport */}
            <motion.div
              whileHover={{ y: -8, scale: 1.02 }}
              className="card-premium p-8 cursor-pointer"
              onClick={() => onNavigate?.('transport')}
            >
              <div 
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6"
                style={{ background: 'linear-gradient(135deg, #00A86B 0%, #2E8B57 100%)' }}
              >
                <Ship className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold mb-3" style={{ color: '#1B4332' }}>
                Real-Time River Transport
              </h3>
              <p className="mb-6" style={{ color: '#666' }}>
                Track boats, book seats, and navigate the Amazon with live departure updates
              </p>
              <button 
                className="flex items-center gap-2 font-semibold transition-colors"
                style={{ color: '#FF4500' }}
              >
                Explore Routes <ArrowRight className="w-5 h-5" />
              </button>
            </motion.div>

            {/* Experiences */}
            <motion.div
              whileHover={{ y: -8, scale: 1.02 }}
              className="card-premium p-8 cursor-pointer"
              onClick={() => onNavigate?.('experiences')}
            >
              <div 
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6"
                style={{ background: 'linear-gradient(135deg, #0077BE 0%, #005A8D 100%)' }}
              >
                <Compass className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold mb-3" style={{ color: '#1B4332' }}>
                Premium Experiences
              </h3>
              <p className="mb-6" style={{ color: '#666' }}>
                Luxury eco-lodges, guided tours, and unforgettable Amazon adventures
              </p>
              <button 
                className="flex items-center gap-2 font-semibold transition-colors"
                style={{ color: '#FF4500' }}
              >
                View Experiences <ArrowRight className="w-5 h-5" />
              </button>
            </motion.div>

            {/* Dining */}
            <motion.div
              whileHover={{ y: -8, scale: 1.02 }}
              className="card-premium p-8 cursor-pointer"
            >
              <div 
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6"
                style={{ background: 'linear-gradient(135deg, #FF4500 0%, #FF6347 100%)' }}
              >
                <UtensilsCrossed className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold mb-3" style={{ color: '#1B4332' }}>
                Authentic Gastronomy
              </h3>
              <p className="mb-6" style={{ color: '#666' }}>
                Reserve tables at the best local restaurants featuring Amazonian cuisine
              </p>
              <button 
                className="flex items-center gap-2 font-semibold transition-colors"
                style={{ color: '#FF4500' }}
              >
                Discover Dining <ArrowRight className="w-5 h-5" />
              </button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Video Section */}
      <section className="py-20 px-12" style={{ backgroundColor: '#1B4332' }}>
        <div className="max-w-[1440px] mx-auto">
          <div className="grid grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-5xl font-bold mb-6 text-white">
                Experience the Amazon Like Never Before
              </h2>
              <p className="text-xl mb-8" style={{ color: '#E8E6E1' }}>
                From sunrise river journeys to luxury jungle retreats, discover why thousands 
                choose Amazon Hub 360 for their Iquitos adventure.
              </p>
              <button
                className="px-8 py-4 rounded-full font-bold text-white transition-all duration-300 hover:shadow-lg hover:scale-105"
                style={{ background: 'linear-gradient(135deg, #FF4500 0%, #FF6347 100%)' }}
              >
                Start Planning Your Trip
              </button>
            </div>
            <div className="relative">
              <div 
                className="aspect-video rounded-3xl overflow-hidden shadow-soft-xl cursor-pointer group"
                style={{ background: 'linear-gradient(135deg, #2E8B57 0%, #00A86B 100%)' }}
              >
                <div className="w-full h-full flex items-center justify-center">
                  <div className="w-20 h-20 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <Play className="w-10 h-10 text-white ml-1" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
