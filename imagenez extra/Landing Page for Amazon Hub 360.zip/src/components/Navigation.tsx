import React from 'react';
import { Compass, Search, User, Menu } from 'lucide-react';

interface NavigationProps {
  currentPage?: string;
  onNavigate?: (page: string) => void;
}

export function Navigation({ currentPage = 'home', onNavigate }: NavigationProps) {
  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'transport', label: 'River Transport' },
    { id: 'experiences', label: 'Experiences' },
    { id: 'restaurants', label: 'Dining' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-lg shadow-soft">
      <div className="max-w-[1440px] mx-auto px-12 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <button 
            onClick={() => onNavigate?.('home')}
            className="flex items-center gap-3 group"
          >
            <div className="w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300"
              style={{ background: 'linear-gradient(135deg, #00A86B 0%, #2E8B57 100%)' }}
            >
              <Compass className="w-7 h-7 text-white" />
            </div>
            <div className="text-left">
              <h1 className="text-xl font-bold" style={{ color: '#1B4332' }}>Amazon Hub 360</h1>
              <p className="text-xs" style={{ color: '#00A86B' }}>Iquitos, Peru</p>
            </div>
          </button>

          {/* Nav Items */}
          <div className="flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate?.(item.id)}
                className={`text-sm font-medium transition-all duration-300 px-4 py-2 rounded-full ${
                  currentPage === item.id
                    ? 'text-white'
                    : 'hover:bg-[#F5F5DC]'
                }`}
                style={currentPage === item.id ? { background: 'linear-gradient(135deg, #00A86B 0%, #2E8B57 100%)' } : { color: '#1B4332' }}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Utility Actions */}
          <div className="flex items-center gap-4">
            <button className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#F5F5DC] transition-colors">
              <Search className="w-5 h-5" style={{ color: '#1B4332' }} />
            </button>
            <button className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#F5F5DC] transition-colors">
              <User className="w-5 h-5" style={{ color: '#1B4332' }} />
            </button>
            <button 
              className="px-6 py-3 rounded-full font-semibold text-white transition-all duration-300 hover:shadow-lg"
              style={{ background: 'linear-gradient(135deg, #FF4500 0%, #FF6347 100%)' }}
            >
              Sign In
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
