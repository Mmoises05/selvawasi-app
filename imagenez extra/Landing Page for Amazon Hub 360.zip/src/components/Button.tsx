import React from 'react';

interface ButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  onClick?: () => void;
  className?: string;
}

export function Button({ 
  children, 
  variant = 'primary', 
  size = 'md',
  onClick,
  className = ''
}: ButtonProps) {
  const baseStyles = 'inline-flex items-center justify-center rounded-full transition-all duration-300 font-medium';
  
  const variants = {
    primary: 'bg-[#FF6B35] text-white hover:bg-[#e55a28] shadow-lg hover:shadow-xl',
    secondary: 'bg-[#0A3323] text-white hover:bg-[#0a4230] shadow-md',
    outline: 'border-2 border-[#0A3323] text-[#0A3323] hover:bg-[#0A3323] hover:text-white'
  };
  
  const sizes = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3 text-base',
    lg: 'px-8 py-4 text-lg'
  };
  
  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`}
      onClick={onClick}
    >
      {children}
    </button>
  );
}
